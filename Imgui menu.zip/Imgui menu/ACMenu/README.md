# ACMenu — Animal Company ImGui .so

## Build

### 1. Get ImGui
```bash
cd jni
git clone https://github.com/ocornut/imgui.git
```

### 2. Open in Android Studio
- File > Open > select this folder
- Let Gradle/CMake sync
- Build > Make Project
- Output: `app/build/intermediates/cmake/debug/obj/arm64-v8a/libacmenu.so`

Or build via NDK directly:
```bash
ndk-build NDK_PROJECT_PATH=. APP_BUILD_SCRIPT=jni/Android.mk
```

---

## Deploy (Frida Gadget sideload)

1. Repack Animal Company APK with frida-gadget:
   ```
   apktool d AnimalCompany.apk
   # copy libfrida-gadget.so -> lib/arm64-v8a/
   # copy libacmenu.so       -> lib/arm64-v8a/
   # copy frida-gadget-config.json -> lib/arm64-v8a/libfrida-gadget.config.so
   # add loadLibrary("frida-gadget") to MainActivity or use objection repack
   apktool b AnimalCompany -o AnimalCompany_mod.apk
   ```

2. Sign & install:
   ```bash
   apksigner sign --ks your.keystore AnimalCompany_mod.apk
   adb install AnimalCompany_mod.apk
   ```

3. The menu shows on launch — drag to reposition, use touch to interact.

---

## Wiring up features

Feature flags in `ModMenu.h` are global bools/floats — read them from your BNM hooks:

```cpp
#include "ModMenu.h"

// In your speed hook:
if (g_speedHack)
    speed *= g_speedMult;

// Feed player list each frame:
Menu_SetPlayers(myPlayerVector);
```

## Notes
- GOT patch targets `eglSwapBuffers` in `libunity.so` — works on Unity 2021/2022
- If Dobby is available, swap `UnityHook_PatchEGL` for `DobbyHook` for more stability
- Touch input is forwarded via `imgui_impl_android` — no controller support yet
