#include <jni.h>
#include <android/log.h>
#include <EGL/egl.h>
#include <GLES3/gl3.h>
#include <dlfcn.h>
#include <pthread.h>
#include <unistd.h>

#include "imgui.h"
#include "backends/imgui_impl_android.h"
#include "backends/imgui_impl_opengl3.h"
#include "hooks/UnityHook.h"
#include "ModMenu.h"

#define TAG  "ACMenu"
#define LOGI(...) __android_log_print(ANDROID_LOG_INFO,  TAG, __VA_ARGS__)
#define LOGE(...) __android_log_print(ANDROID_LOG_ERROR, TAG, __VA_ARGS__)

// ── EGL hook state ────────────────────────────────────────────────────────────

using eglSwapBuffers_t = EGLBoolean(*)(EGLDisplay, EGLSurface);
static eglSwapBuffers_t orig_eglSwapBuffers = nullptr;
static bool             g_imguiInit         = false;
static ANativeWindow*   g_window            = nullptr;

static void InitImGui(EGLDisplay dpy, EGLSurface surf)
{
    if (g_imguiInit) return;
    g_imguiInit = true;

    EGLint w = 0, h = 0;
    eglQuerySurface(dpy, surf, EGL_WIDTH,  &w);
    eglQuerySurface(dpy, surf, EGL_HEIGHT, &h);
    LOGI("ImGui init: %dx%d", w, h);

    IMGUI_CHECKVERSION();
    ImGui::CreateContext();

    ImGuiIO& io   = ImGui::GetIO();
    io.DisplaySize = ImVec2((float)w, (float)h);
    io.IniFilename = nullptr;

    // Quest 2 native res ~1832x1920 per eye — scale UI up
    ImGui::GetStyle().ScaleAllSizes(3.0f);
    io.FontGlobalScale = 3.0f;

    ImGui_ImplAndroid_Init(g_window);
    ImGui_ImplOpenGL3_Init("#version 300 es");

    LOGI("ImGui ready");
}

// ── Hooked eglSwapBuffers ─────────────────────────────────────────────────────

EGLBoolean hook_eglSwapBuffers(EGLDisplay dpy, EGLSurface surf)
{
    InitImGui(dpy, surf);

    // New frame
    ImGui_ImplOpenGL3_NewFrame();
    ImGui_ImplAndroid_NewFrame();
    ImGui::NewFrame();

    DrawMenu();

    ImGui::Render();
    ImGui_ImplOpenGL3_RenderDrawData(ImGui::GetDrawData());

    return orig_eglSwapBuffers(dpy, surf);
}

// ── Touch input relay (called from UnityHook) ─────────────────────────────────

extern "C" void ACMenu_HandleTouch(AInputEvent* event)
{
    if (g_imguiInit)
        ImGui_ImplAndroid_HandleInputEvent(event);
}

// ── PLT hook for eglSwapBuffers ───────────────────────────────────────────────

static void HookEGL()
{
    // Find libEGL in the process and hook eglSwapBuffers via inline hook
    // Using a simple GOT/PLT redirect via dlsym + manual patch
    void* eglLib = dlopen("libEGL.so", RTLD_NOW | RTLD_NOLOAD);
    if (!eglLib) {
        LOGE("libEGL.so not found");
        return;
    }

    orig_eglSwapBuffers = (eglSwapBuffers_t)dlsym(eglLib, "eglSwapBuffers");
    if (!orig_eglSwapBuffers) {
        LOGE("eglSwapBuffers symbol not found");
        return;
    }

    // MSHook / inline ARM64 trampoline
    // If you have Dobby or MSHook available, replace this block:
    //   DobbyHook((void*)orig_eglSwapBuffers, (void*)hook_eglSwapBuffers, (void**)&orig_eglSwapBuffers);
    // For now we patch the GOT of libunity.so which imports eglSwapBuffers

    UnityHook_PatchEGL((void*)hook_eglSwapBuffers, (void**)&orig_eglSwapBuffers);
    LOGI("eglSwapBuffers hooked");
}

// ── Init thread ───────────────────────────────────────────────────────────────

static void* InitThread(void*)
{
    LOGI("ACMenu loaded — waiting for Unity...");
    sleep(3); // give Unity time to init GL

    HookEGL();
    return nullptr;
}

// ── .so constructor ───────────────────────────────────────────────────────────

__attribute__((constructor))
static void OnLoad()
{
    LOGI("ACMenu constructor");
    pthread_t t;
    pthread_create(&t, nullptr, InitThread, nullptr);
    pthread_detach(t);
}
