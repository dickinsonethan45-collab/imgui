#pragma once
#include <android/input.h>

// Patches libunity.so's GOT entry for eglSwapBuffers
void UnityHook_PatchEGL(void* hookFn, void** origFn);
