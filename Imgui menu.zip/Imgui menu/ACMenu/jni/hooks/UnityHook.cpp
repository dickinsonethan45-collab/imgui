#include "UnityHook.h"
#include <android/log.h>
#include <dlfcn.h>
#include <stdio.h>
#include <string.h>
#include <stdint.h>
#include <sys/mman.h>
#include <elf.h>
#include <link.h>

#define TAG  "ACMenu"
#define LOGI(...) __android_log_print(ANDROID_LOG_INFO,  TAG, __VA_ARGS__)
#define LOGE(...) __android_log_print(ANDROID_LOG_ERROR, TAG, __VA_ARGS__)

// ── Read /proc/self/maps to find libunity.so base ────────────────────────────

static uintptr_t FindModuleBase(const char* name)
{
    FILE* f = fopen("/proc/self/maps", "r");
    if (!f) return 0;

    char line[512];
    uintptr_t base = 0;
    while (fgets(line, sizeof(line), f)) {
        if (strstr(line, name)) {
            base = (uintptr_t)strtoull(line, nullptr, 16);
            break;
        }
    }
    fclose(f);
    return base;
}

// ── Walk ELF GOT and patch eglSwapBuffers ────────────────────────────────────

void UnityHook_PatchEGL(void* hookFn, void** origFn)
{
    // We need the base of libunity.so
    uintptr_t base = FindModuleBase("libunity.so");
    if (!base) {
        LOGE("libunity.so base not found");
        return;
    }
    LOGI("libunity.so base: 0x%lx", (unsigned long)base);

    // Parse ELF header
    auto* ehdr = (Elf64_Ehdr*)base;
    if (ehdr->e_ident[0] != 0x7f || ehdr->e_ident[1] != 'E') {
        LOGE("Bad ELF magic");
        return;
    }

    auto* phdr = (Elf64_Phdr*)(base + ehdr->e_phoff);

    // Find DYNAMIC segment
    Elf64_Dyn* dyn = nullptr;
    for (int i = 0; i < ehdr->e_phnum; i++) {
        if (phdr[i].p_type == PT_DYNAMIC) {
            dyn = (Elf64_Dyn*)(base + phdr[i].p_vaddr);
            break;
        }
    }
    if (!dyn) { LOGE("No DYNAMIC segment"); return; }

    // Walk dynamic section
    Elf64_Rela* rela    = nullptr;
    size_t      relaSz  = 0;
    size_t      relaEnt = sizeof(Elf64_Rela);
    const char* strtab  = nullptr;
    Elf64_Sym*  symtab  = nullptr;

    for (Elf64_Dyn* d = dyn; d->d_tag != DT_NULL; d++) {
        switch (d->d_tag) {
            case DT_JMPREL:  rela   = (Elf64_Rela*)(base + d->d_un.d_ptr); break;
            case DT_PLTRELSZ:relaSz = d->d_un.d_val; break;
            case DT_RELAENT: relaEnt= d->d_un.d_val; break;
            case DT_STRTAB:  strtab = (const char*)(base + d->d_un.d_ptr); break;
            case DT_SYMTAB:  symtab = (Elf64_Sym*)(base + d->d_un.d_ptr); break;
            default: break;
        }
    }

    if (!rela || !strtab || !symtab) {
        LOGE("Missing ELF tables (rela=%p strtab=%p symtab=%p)", rela, strtab, symtab);
        return;
    }

    size_t count = relaSz / relaEnt;
    for (size_t i = 0; i < count; i++) {
        Elf64_Rela* r   = (Elf64_Rela*)((uint8_t*)rela + i * relaEnt);
        uint32_t    sym = ELF64_R_SYM(r->r_info);
        const char* name = strtab + symtab[sym].st_name;

        if (strcmp(name, "eglSwapBuffers") == 0) {
            void** got = (void**)(base + r->r_offset);

            // Save original
            *origFn = *got;

            // Make page writable
            uintptr_t page = (uintptr_t)got & ~(uintptr_t)(getpagesize() - 1);
            mprotect((void*)page, getpagesize(), PROT_READ | PROT_WRITE);

            // Patch
            *got = hookFn;

            // Restore
            mprotect((void*)page, getpagesize(), PROT_READ);

            LOGI("GOT patch: eglSwapBuffers @ %p -> %p (orig %p)", got, hookFn, *origFn);
            return;
        }
    }

    LOGE("eglSwapBuffers not found in libunity.so GOT");
}
